#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "imageData.h"
#include "functions.h"
#include "solution.h"

#define IMAGE_WIDTH 480
#define IMAGE_HEIGHT 320

Image *initializeInput();
int checkRadius(int stud,int sol);
int checkGausFilter(double *stud,double *sol,int size);
int checkImage(Image *stud,Image *sol);
double imageError(Image *stud,Image *sol);

int main(int argc, char *argv[] )
{
    if (argc == 1){
	printf("Run as ./grade test_num, where test_num is 0 for calcCosineFilter, 1 for convertToGray, 2 for invertImage, 3 for colorThreshold , 4 for ConvolveImage, 5 for Challenge 1, 6 for Challenge 2\n");
	return 0;
    }
    int command;
    sscanf(argv[1],"%d",&command);

  Image *inputImage=initializeInput();
  Image *studImage=generateOutput(inputImage);
  Image *solImage=generateOutput(inputImage);
  const double gMonoMult[3]={.299,.587,.114};

  if(command==0){
	  int score = 0;
	  int radius = 1;
	  int size=(2*radius+1)*(2*radius+1);
	  double *cosFilter1=(double*)malloc(sizeof(double)*size);
	  double *cosFilterSol1=(double*)malloc(sizeof(double)*size);
	  printf("Testing calculateCosineFilter with Radius=%d:\n",radius);
	  calculateCosineFilter(cosFilter1,radius);
	  calculateCosineFilterSol(cosFilterSol1,radius);
	  if(!checkGausFilter(cosFilter1,cosFilterSol1,size))
	  {
	    printf("calculateCosineFilter correct (5/5)\n");
	    score = score+5;
	  }
	  else	
	  {
	    printf("calculateCosineFilter incorrect, Error >0.002 (0/5)\n");
	  }

	  radius = 2;
	  size=(2*radius+1)*(2*radius+1);
	  double *cosFilter=(double*)malloc(sizeof(double)*size);
	  double *cosFilterSol=(double*)malloc(sizeof(double)*size);
	  printf("Testing calculateCosineFilter with Radius=%d:\n",radius);
	  calculateCosineFilter(cosFilter,radius);
	  calculateCosineFilterSol(cosFilterSol,radius);
	  if(!checkGausFilter(cosFilter,cosFilterSol,size))
	  {
	    printf("calculateCosineFilter correct (5/5)\n");
	    score = score+5;
	  }
	  else	
	  {
	    printf("calculateCosineFilter incorrect, Error >0.002(0/5)\n");
	  }

	  radius = 3;
	  size=(2*radius+1)*(2*radius+1);
	  double *cosFilter2=(double*)malloc(sizeof(double)*size);
	  double *cosFilterSol2=(double*)malloc(sizeof(double)*size);
	  printf("Testing calculateCosineFilter with Radius=%d:\n",radius);
	  calculateCosineFilter(cosFilter2,radius);
	  calculateCosineFilterSol(cosFilterSol2,radius);
	  if(!checkGausFilter(cosFilter2,cosFilterSol2,size))
	  {
	    printf("calculateCosineFilter correct (10/10)\n");
            score = score+10;
	  }
	  else	
	  {
	    printf("calculateCosineFilter incorrect, Error >0.002(0/10)\n");
	  }
	  printf("*************calculateCosineFilter Score:%d/20*************",score);
	  free(cosFilter);
	  free(cosFilterSol);
	  free(cosFilter1);
	  free(cosFilterSol1);
  	  free(cosFilter2);
  	  free(cosFilterSol2);
  }
  uint8_t *inRed=inputImage->redChannel;
  uint8_t *inGreen=inputImage->greenChannel;
  uint8_t *inBlue=inputImage->blueChannel;
  uint8_t *inAlpha=inputImage->alphaChannel;
  uint8_t *studRed=studImage->redChannel;
  uint8_t *studGreen=studImage->greenChannel;
  uint8_t *studBlue=studImage->blueChannel;
  uint8_t *studAlpha=studImage->alphaChannel;
  uint8_t *solRed=solImage->redChannel;
  uint8_t *solGreen=solImage->greenChannel;
  uint8_t *solBlue=solImage->blueChannel;
  uint8_t *solAlpha=solImage->alphaChannel;
  
  if(command==4){
	int score = 0;
	  int radius = 7;
	  printf("\nTesting convolveImage with Cosine Filter, radius=%d:\n",radius);
	  int size=(2*radius+1)*(2*radius+1);
	  double *cosFilterTest=(double*)malloc(sizeof(double)*size);
	  calculateCosineFilterSol(cosFilterTest,radius);

	  convolveImage(inRed,inGreen,inBlue,inAlpha,studRed,studGreen,studBlue,
		        studAlpha,cosFilterTest,radius,IMAGE_WIDTH,IMAGE_HEIGHT);
	  convolveImageSol(inRed,inGreen,inBlue,inAlpha,solRed,solGreen,solBlue,
		           solAlpha,cosFilterTest,radius,IMAGE_WIDTH,IMAGE_HEIGHT);
	  double convolveError = 0.00005;
	  double stuError = imageError(studImage,solImage); 
	  if(stuError<convolveError)
	  {
	    printf("convolveImage correct with error %lf < %lf\n",stuError,convolveError);
		score = score+25;
	  }
	  else
	  {
	    printf("convolveImage incorrect with error %lf > %lf\n",stuError,convolveError);
	    if(stuError<0.00050){
		score = 20;
	    }else if(stuError<0.005){
		score = 15;
	    }else if(stuError<0.05){
		score = 10;
	    }else if(stuError<0.5){
		score = 5;
	    }
	  }
	  printf("*************convolveImage Score:%d/25*************",score);
	  free(cosFilterTest);
    }

    if(command==1){
	  int score = 0;
	  printf("\nTesting convertToGray\n");
	  convertToGray(inRed,inGreen,inBlue,inAlpha,studRed,studGreen,studBlue,
		        studAlpha,gMonoMult,IMAGE_WIDTH,IMAGE_HEIGHT);
	  convertToGraySol(inRed,inGreen,inBlue,inAlpha,solRed,solGreen,solBlue,
		           solAlpha,gMonoMult,IMAGE_WIDTH,IMAGE_HEIGHT);
	  if(!checkImage(studImage,solImage))
	  {
	    score = 15;
	    printf("convertToGray correct\n");
	  }
	  else
	  {
	    printf("convertToGray incorrect\n");
	  }
	  printf("*************convertToGray Score:%d/15*************",score);
    }
    if(command==2){
	  int score = 0;
	  printf("\nTesting invertImage:\n");
	  invertImage(inRed,inGreen,inBlue,inAlpha,studRed,studGreen,studBlue,
		      studAlpha,IMAGE_WIDTH,IMAGE_HEIGHT);
	  invertImageSol(inRed,inGreen,inBlue,inAlpha,solRed,solGreen,solBlue,
		         solAlpha,IMAGE_WIDTH,IMAGE_HEIGHT);
	  if(!checkImage(studImage,solImage))
	  {
	    score = 15;
	    printf("invertImage correct\n");
	  }
	  else
	  {
	    printf("invertImage incorrect\n");
	  }
	  printf("*************invertImage Score:%d/15*************",score);
    }
    if(command==3){
	  int score = 0;
	  printf("\nTesting Color Threshold\n R Thres=20 B Thres = 100 G Thres = 40:\n");
	colorThreshold(inRed,inGreen,inBlue,inAlpha,studRed,studGreen,studBlue,
		      studAlpha,IMAGE_WIDTH,IMAGE_HEIGHT,20,100,40);
	  colorThresholdSol(inRed,inGreen,inBlue,inAlpha,solRed,solGreen,solBlue,
		         solAlpha,IMAGE_WIDTH,IMAGE_HEIGHT,20,100,40);
	  if(!checkImage(studImage,solImage))
	  {
	    score = 15;
	    printf("Color Threshold correct\n");
	  }
	  else
	  {
	    printf("Color Threshold incorrect\n");
	  }
          printf("*************colorThreshold Score:%d/15*************",score);
    }

    if(command==5){
	  printf("\nChallenge 1\n");
	  int score = 0;
 	  printf("Testing transformImage\n");
	  /*test cases for transform*/
	  double acceptableError = 0.03;
	  /*shift*/
	  double computedError;
	  /*scale*/
	  double transform2[2][2]={{0.5,0},{0,0.5}};
	  transformImageSol(inRed,inGreen,inBlue,inAlpha,
		      solRed,solGreen,solBlue,
		      solAlpha,transform2,IMAGE_WIDTH,IMAGE_HEIGHT);
	  transformImage(inRed,inGreen,inBlue,inAlpha,
		      studRed,studGreen,studBlue,
		      studAlpha,transform2,IMAGE_WIDTH,IMAGE_HEIGHT);
	  computedError = imageError(studImage,solImage);
	  if(computedError<acceptableError)
	  {
		printf("transformImage with transform1.txt correct with error: %lf < %lf (3/3)\n",computedError,acceptableError);
		score = score+3;
	  }
	  else
	  {	
		printf("transformImage with transform1.txt incorrect with error: %lf > %lf (0/3)\n",computedError,acceptableError); 
	  }
	  /*rotate*/
	  double transform3[2][2]={{cos(35),-sin(35)},{sin(35),cos(35)}};
	  transformImageSol(inRed,inGreen,inBlue,inAlpha,
		      solRed,solGreen,solBlue,
		      solAlpha,transform3,IMAGE_WIDTH,IMAGE_HEIGHT);
	  transformImage(inRed,inGreen,inBlue,inAlpha,
		      studRed,studGreen,studBlue,
		      studAlpha,transform3,IMAGE_WIDTH,IMAGE_HEIGHT);
	  computedError = imageError(studImage,solImage);
	  if(computedError<acceptableError)
	  {
		printf("transformImage with transform2.txt correct with error: %lf < %lf (4/4)\n",computedError,acceptableError);
		score = score+4;
	  }
	  else
	  {	
		printf("transformImage with transform2.txt incorrect with error: %lf > %lf (0/4)\n",computedError,acceptableError); 
	  }
	  /*scale 2*/
	  double transform4[2][2]={{1.2,0},{0,1.2}};
	  transformImageSol(inRed,inGreen,inBlue,inAlpha,
		      solRed,solGreen,solBlue,
		      solAlpha,transform4,IMAGE_WIDTH,IMAGE_HEIGHT);
	  transformImage(inRed,inGreen,inBlue,inAlpha,
		      studRed,studGreen,studBlue,
		      studAlpha,transform4,IMAGE_WIDTH,IMAGE_HEIGHT);
	  computedError =imageError(studImage,solImage);
	  if(computedError<acceptableError)
	  {
		score = score+4;
		printf("transformImage with transform3.txt correct with error: %lf < %lf (4/4)\n",computedError,acceptableError);
	  }
	  else
	  {	
		printf("transformImage with transform3.txt incorrect with error: %lf > %lf (0/4)\n",computedError,acceptableError); 
	  }
	  /*skew*/
	  double transform5[2][2]={{0.8,0.2},{0.3,0.5}};
	  transformImageSol(inRed,inGreen,inBlue,inAlpha,
		      solRed,solGreen,solBlue,
		      solAlpha,transform5,IMAGE_WIDTH,IMAGE_HEIGHT);
	  transformImage(inRed,inGreen,inBlue,inAlpha,
		      studRed,studGreen,studBlue,
		      studAlpha,transform5,IMAGE_WIDTH,IMAGE_HEIGHT);
	  computedError = imageError(studImage,solImage);
	  if(computedError<acceptableError)
	  {
		printf("transformImage with transform4.txt correct with error: %lf < %lf (4/4)\n",computedError,acceptableError);
		score = score+4;
	  }
	  else
	  {	
		printf("transformImage with transform4.txt incorrect with error: %lf > %lf (0/4)\n",computedError,acceptableError); 
	  }
	  printf("*************Challenge 1 Score:%d/15*************",score);
  }
  if(command ==6){
	int score = 0;
	int testsPassed = 0;
	  printf("\nChallenge 2\n");
	  char mainFileName[] = "./Images/numbers.png";
	  char targetFileName[] = "./Images/seven.png";
	  char target2FileName[] = "./Images/eight.png";
	  char noTargetFileName[] = "./Images/E.png";
	  Image *detImage=decode(mainFileName);
	  Image *targetImage=decode(targetFileName);
	  Image *target2Image=decode(target2FileName);
	  Image *noTargetImage=decode(noTargetFileName);
	  int row,col,rowstu,colstu;
	  detectImage(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&colstu,&rowstu,targetImage->redChannel,targetImage->blueChannel,targetImage->greenChannel,targetImage->alphaChannel,
		           detImage->width,detImage->height,targetImage->width,targetImage->height);

	  detectImageSol(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&col,&row,targetImage->redChannel,targetImage->blueChannel,targetImage->greenChannel,targetImage->alphaChannel,
		           detImage->width,detImage->height,targetImage->width,targetImage->height);
	  if (abs(row-rowstu)<2 && abs(col-colstu)<2){
		printf("Detect Seven.png Correct within 1 pixel row: %d col: %d \n",row,col);
		testsPassed = testsPassed+1;
	  }else{
		printf("Detect Seven.png Incorrect row: %d col: %d correct row: %d correct col: %d \n",rowstu,colstu,row,col);
	  }

	  detectImage(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&colstu,&rowstu,target2Image->redChannel,target2Image->blueChannel,target2Image->greenChannel,target2Image->alphaChannel,
		           detImage->width,detImage->height,target2Image->width,target2Image->height);

	  detectImageSol(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&col,&row,target2Image->redChannel,target2Image->blueChannel,target2Image->greenChannel,target2Image->alphaChannel,
		           detImage->width,detImage->height,target2Image->width,target2Image->height);
	  if (abs(row-rowstu)<2 && abs(col-colstu)<2){
		printf("Detect Eight.png Correct within 1 pixel row: %d col: %d \n",row,col);
	        testsPassed = testsPassed+1;
	  }else{
		printf("Detect Eight.png Incorrect row: %d col: %d correct row: %d correct col: %d \n",rowstu,colstu,row,col);
	  }
	  detectImage(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&colstu,&rowstu,noTargetImage->redChannel,noTargetImage->blueChannel,noTargetImage->greenChannel,noTargetImage->alphaChannel,
		           detImage->width,detImage->height,noTargetImage->width,noTargetImage->height);

	  detectImageSol(detImage->redChannel,detImage->greenChannel,detImage->blueChannel,
		           detImage->alphaChannel,&col,&row,noTargetImage->redChannel,noTargetImage->blueChannel,noTargetImage->greenChannel,noTargetImage->alphaChannel,
		           detImage->width,detImage->height,noTargetImage->width,noTargetImage->height);

	  if (row==rowstu && col==colstu){
		printf("Detect E.png Correct row: %d col: %d \n",row,col);
		testsPassed = testsPassed+1;
	  }else{
		printf("Detect E.png Incorrect row: %d col: %d Correct row: %d correct col: %d \n",rowstu,colstu,row,col);
	  }
	  if(testsPassed>1){
		score = 15.0*(testsPassed/3.0);
	  }else{
		printf("Did not pass at least two tests\n");
	  }
	  printf("*************Challenge 2 Score:%d/15*************\n",score);
	  freeImage(detImage);
	  freeImage(targetImage);
	  freeImage(target2Image);
  	  freeImage(noTargetImage);
  }

  freeImage(inputImage);
  freeImage(studImage);
  freeImage(solImage);
  return 0;
}

int checkRadius(int stud,int sol)
{
  if(stud!=sol)
    return -1;
  return 0;
}

int checkGausFilter(double *stud,double *sol,int size)
{
  int i;
  for(i=0;i<size;i++)
    if(fabs(sol[i]-stud[i])>.002)
      return -1;
  return 0;
}

int checkImage(Image *stud,Image *sol)
{
  uint8_t *studRed=stud->redChannel;
  uint8_t *studGreen=stud->greenChannel;
  uint8_t *studBlue=stud->blueChannel;
  uint8_t *studAlpha=stud->alphaChannel;
  uint8_t *solRed=sol->redChannel;
  uint8_t *solGreen=sol->greenChannel;
  uint8_t *solBlue=sol->blueChannel;
  uint8_t *solAlpha=sol->alphaChannel;

  int loc,row,col;
  for(row=0;row<IMAGE_HEIGHT;row++)
    for(col=0;col<IMAGE_WIDTH;col++)
    {
      loc=row*IMAGE_WIDTH+col;
      if(studRed[loc]!=solRed[loc])
        return -1;
      if(studGreen[loc]!=solGreen[loc])
        return -1;
      if(studBlue[loc]!=solBlue[loc])
        return -1;
      if(studAlpha[loc]!=solAlpha[loc])
        return -1;
    }

  return 0;
}

Image *initializeInput()
{
  int row,col;
  Image *newImage=(Image*)malloc(sizeof(Image));
  newImage->redChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImage->greenChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImage->blueChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImage->alphaChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);

  for(row=0;row<IMAGE_HEIGHT;row++)
    for(col=0;col<IMAGE_WIDTH;col++)
    {
      newImage->redChannel[row*IMAGE_WIDTH+col]=rand()%256;
      newImage->greenChannel[row*IMAGE_WIDTH+col]=rand()%256;
      newImage->blueChannel[row*IMAGE_WIDTH+col]=rand()%256;
      newImage->alphaChannel[row*IMAGE_WIDTH+col]=255;
    }
  newImage->width=IMAGE_WIDTH;
  newImage->height=IMAGE_HEIGHT;
  double sigma=1;
  int radius=getRadiusSol(sigma);
  int size=(2*radius+1)*(2*radius+1);
  double *gausFilterSol=(double*)malloc(sizeof(double)*size);
  calculateGausFilterSol(gausFilterSol,sigma);

  Image *newImageOut=(Image*)malloc(sizeof(Image));
  newImageOut->redChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImageOut->greenChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImageOut->blueChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);
  newImageOut->alphaChannel=(uint8_t*)malloc(sizeof(uint8_t)*IMAGE_HEIGHT*IMAGE_WIDTH);

  uint8_t *inRed=newImage->redChannel;
  uint8_t *inGreen=newImage->greenChannel;
  uint8_t *inBlue=newImage->blueChannel;
  uint8_t *inAlpha=newImage->alphaChannel;
  uint8_t *outRed=newImageOut->redChannel;
  uint8_t *outGreen=newImageOut->greenChannel;
  uint8_t *outBlue=newImageOut->blueChannel;
  uint8_t *outAlpha=newImageOut->alphaChannel;
  newImageOut->width=IMAGE_WIDTH;
  newImageOut->height=IMAGE_HEIGHT;
  
convolveImageSol(inRed,inGreen,inBlue,inAlpha,outRed,outGreen,outBlue,
                   outAlpha,gausFilterSol,radius,IMAGE_WIDTH,IMAGE_HEIGHT);
  freeImage(newImage);
  free(gausFilterSol);//Forgot to free this! 
  return newImageOut;
}

double imageError(Image *stud,Image *sol)
{
  uint8_t *studRed=stud->redChannel;
  uint8_t *studGreen=stud->greenChannel;
  uint8_t *studBlue=stud->blueChannel;
  uint8_t *solRed=sol->redChannel;
  uint8_t *solGreen=sol->greenChannel;
  uint8_t *solBlue=sol->blueChannel;
  
  double power = 0;/*solution image power*/
  double error = 0;/*error power*/
  int loc,row,col;
  double npix = IMAGE_HEIGHT*IMAGE_WIDTH;
  for(row=0;row<IMAGE_HEIGHT;row++){
    for(col=0;col<IMAGE_WIDTH;col++)
    {
      loc=row*IMAGE_WIDTH+col;
      power = power + (1.0/npix)*(pow((double)solRed[loc],2.0) + pow((double)solGreen[loc],2.0) + pow((double)solBlue[loc],2.0));
      error = error + (1.0/npix)*(pow((double)solRed[loc]-(double)studRed[loc],2.0)+pow((double)solGreen[loc]-(double)studGreen[loc],2.0)+pow((double)solBlue[loc]-(double)studBlue[loc],2.0));
    }
   }
  return error/power;/*return error to signal ratio, want less than 1%*/
}

